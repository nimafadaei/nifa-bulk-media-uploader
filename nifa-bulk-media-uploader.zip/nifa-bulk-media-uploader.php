<?php
/**
 * Plugin Name: Nifa Bulk Media Uploader
 * Plugin URI: https://nifaweb.site
 * Description: افزونه آپلود گروهی تصاویر و ویدیوها از طریق فایل زیپ با رابط کاربری جذاب و استایل glassmorphism
 * Version: 1.0.0
 * Author: Nima Fadaei
 * Author URI: https://nifaweb.site
 * Text Domain: nifa-bulk-media-uploader
 * Domain Path: /languages
 * License: GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('NIFA_BMU_VERSION', '1.0.0');
define('NIFA_BMU_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('NIFA_BMU_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NIFA_BMU_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
require_once NIFA_BMU_PLUGIN_DIR . 'includes/class-nifa-bulk-media-uploader-includes.php';

// Initialize the plugin
function nifa_bulk_media_uploader_init() {
    // Load plugin textdomain
    load_plugin_textdomain('nifa-bulk-media-uploader', false, dirname(NIFA_BMU_PLUGIN_BASENAME) . '/languages');
    
    // Initialize the main plugin class
    $nifa_bulk_media_uploader = new Nifa_Bulk_Media_Uploader();
    $nifa_bulk_media_uploader->init();
}
add_action('plugins_loaded', 'nifa_bulk_media_uploader_init');

// Activation hook
register_activation_hook(__FILE__, 'nifa_bulk_media_uploader_activate');
function nifa_bulk_media_uploader_activate() {
    // Activation tasks
    // Create custom database tables if needed
    // Set default options
    
    // Set default settings
    $default_settings = array(
        'max_file_size' => 50, // Maximum file size in MB
        'allowed_file_types' => array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv'),
        'auto_organize' => true, // Automatically organize uploads by date
        'process_limit' => 20, // Number of files to process per batch
    );
    
    // Only set default settings if they don't exist
    if (!get_option('nifa_bmu_settings')) {
        update_option('nifa_bmu_settings', $default_settings);
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'nifa_bulk_media_uploader_deactivate');
function nifa_bulk_media_uploader_deactivate() {
    // Deactivation tasks
    // Clean up temporary files
    $upload_dir = wp_upload_dir();
    $temp_dir = $upload_dir['basedir'] . '/nifa-bmu-temp';
    
    if (file_exists($temp_dir) && is_dir($temp_dir)) {
        // Remove temporary directory and its contents
        nifa_bmu_remove_directory($temp_dir);
    }
}

// Helper function to remove directory and its contents
function nifa_bmu_remove_directory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        
        if (!nifa_bmu_remove_directory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }
    
    return rmdir($dir);
}

// Uninstall hook (must be a static method or function)
register_uninstall_hook(__FILE__, 'nifa_bulk_media_uploader_uninstall');
function nifa_bulk_media_uploader_uninstall() {
    // Uninstallation tasks
    // Remove plugin options
    delete_option('nifa_bmu_settings');
    
    // Remove any plugin-specific database tables if created
}
