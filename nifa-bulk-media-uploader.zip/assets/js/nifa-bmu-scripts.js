/**
 * Nifa Bulk Media Uploader Frontend Scripts
 * Handles the frontend functionality
 */

(function($) {
    'use strict';

    // Initialize the frontend functionality
    function initFrontend() {
        // Add glassmorphism effect to WordPress media elements
        addGlassmorphismToMediaElements();
        
        // Initialize media grid if present
        initMediaGrid();
    }

    // Add glassmorphism effect to WordPress media elements
    function addGlassmorphismToMediaElements() {
        // Add glassmorphism class to media containers
        $('.wp-block-gallery, .gallery, .wp-block-media-text').addClass('nifa-bmu-container');
        
        // Add button styles to media buttons
        $('.wp-block-button__link').addClass('nifa-bmu-button');
    }

    // Initialize media grid
    function initMediaGrid() {
        const $mediaGrid = $('.nifa-bmu-media-grid');
        
        if ($mediaGrid.length === 0) {
            return;
        }
        
        // Add lightbox functionality to media items
        $('.nifa-bmu-media-item').on('click', function() {
            const mediaUrl = $(this).data('media-url');
            const mediaType = $(this).data('media-type');
            
            if (!mediaUrl) {
                return;
            }
            
            // Create lightbox
            const $lightbox = $('<div class="nifa-bmu-lightbox"></div>');
            const $lightboxContent = $('<div class="nifa-bmu-lightbox-content"></div>');
            const $closeButton = $('<button class="nifa-bmu-lightbox-close">&times;</button>');
            
            // Add media to lightbox
            if (mediaType === 'image') {
                $lightboxContent.append('<img src="' + mediaUrl + '" alt="" />');
            } else if (mediaType === 'video') {
                $lightboxContent.append('<video src="' + mediaUrl + '" controls autoplay></video>');
            }
            
            // Add close button
            $lightboxContent.append($closeButton);
            
            // Add lightbox to body
            $lightbox.append($lightboxContent);
            $('body').append($lightbox);
            
            // Show lightbox
            setTimeout(function() {
                $lightbox.addClass('active');
            }, 10);
            
            // Handle close button click
            $closeButton.on('click', function() {
                $lightbox.removeClass('active');
                
                // Remove lightbox after animation
                setTimeout(function() {
                    $lightbox.remove();
                }, 300);
            });
            
            // Handle click outside content
            $lightbox.on('click', function(e) {
                if (e.target === this) {
                    $closeButton.click();
                }
            });
            
            // Handle ESC key
            $(document).on('keydown.nifa-bmu-lightbox', function(e) {
                if (e.keyCode === 27) {
                    $closeButton.click();
                    $(document).off('keydown.nifa-bmu-lightbox');
                }
            });
        });
    }

    // Initialize when document is ready
    $(document).ready(function() {
        initFrontend();
    });

})(jQuery);
