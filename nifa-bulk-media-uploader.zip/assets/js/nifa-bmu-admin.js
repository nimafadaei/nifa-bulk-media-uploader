/**
 * Nifa Bulk Media Uploader Admin Scripts
 * Handles the upload and processing of ZIP files
 */

(function($) {
    'use strict';

    // Initialize the uploader
    function initUploader() {
        const $form = $('#nifa-bmu-upload-form');
        const $fileInput = $('#nifa-bmu-zip-file');
        const $uploadField = $('.nifa-bmu-upload-field');
        const $fileInfo = $('.nifa-bmu-file-info');
        const $fileName = $('.nifa-bmu-file-name');
        const $fileSize = $('.nifa-bmu-file-size');
        const $progress = $('.nifa-bmu-progress');
        const $progressBar = $('.nifa-bmu-progress-bar-inner');
        const $progressText = $('.nifa-bmu-progress-text');
        const $uploadButton = $('.nifa-bmu-upload-button');
        const $removeButton = $('.nifa-bmu-remove-file');
        const $cancelButton = $('.nifa-bmu-cancel-upload');
        const $results = $('.nifa-bmu-results');
        const $resultsSummary = $('.nifa-bmu-results-summary');
        const $resultsErrors = $('.nifa-bmu-results-errors');
        const $newUploadButton = $('.nifa-bmu-new-upload');

        let xhr = null;
        let processingXhr = null;
        let selectedFile = null;
        let isUploading = false;
        let isProcessing = false;

        // Handle file selection
        $fileInput.on('change', function(e) {
            const files = e.target.files;
            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        });

        // Handle drag and drop
        $uploadField.on('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).addClass('dragover');
        });

        $uploadField.on('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover');
        });

        $uploadField.on('drop', function(e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).removeClass('dragover');
            
            const files = e.originalEvent.dataTransfer.files;
            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        });

        // Handle file selection
        function handleFileSelect(file) {
            // Check if file is a ZIP
            if (file.type !== 'application/zip' && !file.name.toLowerCase().endsWith('.zip')) {
                alert(nifa_bmu_data.strings.error + ': ' + 'Only ZIP files are allowed.');
                return;
            }

            // Check file size
            const maxSize = nifa_bmu_data.settings.max_file_size * 1024 * 1024; // Convert MB to bytes
            if (file.size > maxSize) {
                alert(nifa_bmu_data.strings.error + ': ' + 'File size exceeds the maximum allowed size.');
                return;
            }

            selectedFile = file;
            
            // Update file info
            $fileName.text(file.name);
            $fileSize.text(formatFileSize(file.size));
            $fileInfo.show();
            $uploadField.hide();
        }

        // Format file size
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        // Handle remove button click
        $removeButton.on('click', function() {
            resetUploader();
        });

        // Handle cancel button click
        $cancelButton.on('click', function() {
            if (confirm(nifa_bmu_data.strings.confirm_cancel)) {
                if (xhr && xhr.readyState !== 4) {
                    xhr.abort();
                }
                
                if (processingXhr && processingXhr.readyState !== 4) {
                    processingXhr.abort();
                }
                
                resetUploader();
            }
        });

        // Handle new upload button click
        $newUploadButton.on('click', function() {
            resetUploader();
            $results.hide();
        });

        // Reset uploader
        function resetUploader() {
            $fileInput.val('');
            $fileInfo.hide();
            $uploadField.show();
            $progress.hide();
            $progressBar.css('width', '0%');
            $progressText.text('0%');
            selectedFile = null;
            isUploading = false;
            isProcessing = false;
        }

        // Handle form submission
        $form.on('submit', function(e) {
            e.preventDefault();
            
            if (!selectedFile) {
                alert(nifa_bmu_data.strings.error + ': ' + 'Please select a ZIP file.');
                return;
            }
            
            if (isUploading || isProcessing) {
                return;
            }
            
            uploadFile();
        });

        // Upload file
        function uploadFile() {
            isUploading = true;
            
            // Show progress
            $fileInfo.hide();
            $progress.show();
            $progressBar.css('width', '0%');
            $progressText.text('0%');
            $progressText.text(nifa_bmu_data.strings.uploading);
            
            // Create FormData
            const formData = new FormData();
            formData.append('action', 'nifa_bmu_upload_zip');
            formData.append('nonce', nifa_bmu_data.nonce.upload);
            formData.append('zip_file', selectedFile);
            
            // Send AJAX request
            xhr = $.ajax({
                url: nifa_bmu_data.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                xhr: function() {
                    const xhr = new window.XMLHttpRequest();
                    
                    // Upload progress
                    xhr.upload.addEventListener('progress', function(e) {
                        if (e.lengthComputable) {
                            const percent = Math.round((e.loaded / e.total) * 100);
                            $progressBar.css('width', percent + '%');
                            $progressText.text(nifa_bmu_data.strings.uploading + ' ' + percent + '%');
                        }
                    }, false);
                    
                    return xhr;
                },
                success: function(response) {
                    isUploading = false;
                    
                    if (response.success) {
                        // Start processing the ZIP file
                        processZipFile(response.data.file_path);
                    } else {
                        // Show error
                        alert(nifa_bmu_data.strings.error + ': ' + response.data.message);
                        resetUploader();
                    }
                },
                error: function() {
                    isUploading = false;
                    alert(nifa_bmu_data.strings.error + ': ' + 'An error occurred during upload.');
                    resetUploader();
                }
            });
        }

        // Process ZIP file
        function processZipFile(filePath, offset = 0) {
            isProcessing = true;
            
            // Update progress text
            $progressText.text(nifa_bmu_data.strings.processing);
            
            // Send AJAX request
            processingXhr = $.ajax({
                url: nifa_bmu_data.ajax_url,
                type: 'POST',
                data: {
                    action: 'nifa_bmu_process_zip',
                    nonce: nifa_bmu_data.nonce.process,
                    file_path: filePath,
                    offset: offset
                },
                success: function(response) {
                    if (response.success) {
                        const data = response.data;
                        
                        // Update progress
                        const percent = Math.round((data.offset / data.total) * 100);
                        $progressBar.css('width', percent + '%');
                        $progressText.text(nifa_bmu_data.strings.processing + ' ' + percent + '%');
                        
                        // Check if processing is completed
                        if (data.is_completed) {
                            isProcessing = false;
                            
                            // Show results
                            $progress.hide();
                            $results.show();
                            
                            // Update results summary
                            $resultsSummary.html(
                                '<p><strong>' + data.message + '</strong></p>' +
                                '<p>Total files: ' + data.total + '</p>' +
                                '<p>Uploaded files: ' + data.uploaded + '</p>' +
                                '<p>Skipped files: ' + data.skipped + '</p>'
                            );
                            
                            // Update results errors
                            if (data.errors.length > 0) {
                                let errorsHtml = '';
                                for (let i = 0; i < data.errors.length; i++) {
                                    errorsHtml += '<p>' + data.errors[i] + '</p>';
                                }
                                $resultsErrors.html(errorsHtml);
                            } else {
                                $resultsErrors.html('<p>No errors occurred during processing.</p>');
                            }
                        } else {
                            // Continue processing
                            processZipFile(filePath, data.offset);
                        }
                    } else {
                        // Show error
                        isProcessing = false;
                        alert(nifa_bmu_data.strings.error + ': ' + response.data.message);
                        resetUploader();
                    }
                },
                error: function() {
                    isProcessing = false;
                    alert(nifa_bmu_data.strings.error + ': ' + 'An error occurred during processing.');
                    resetUploader();
                }
            });
        }
    }

    // Initialize when document is ready
    $(document).ready(function() {
        initUploader();
    });

})(jQuery);
