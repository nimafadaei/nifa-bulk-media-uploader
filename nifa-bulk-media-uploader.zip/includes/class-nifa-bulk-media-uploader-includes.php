<?php
/**
 * Update the main plugin file to include the new classes
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Include required files
require_once NIFA_BMU_PLUGIN_DIR . 'includes/class-nifa-bulk-media-uploader.php';
require_once NIFA_BMU_PLUGIN_DIR . 'includes/class-nifa-bulk-media-uploader-admin.php';
require_once NIFA_BMU_PLUGIN_DIR . 'includes/class-nifa-bulk-media-uploader-zip-handler.php';
require_once NIFA_BMU_PLUGIN_DIR . 'includes/class-nifa-bulk-media-uploader-media-processor.php';

// Include test class if in test mode
if (defined('NIFA_BMU_TEST_MODE') && NIFA_BMU_TEST_MODE) {
    require_once NIFA_BMU_PLUGIN_DIR . 'includes/class-nifa-bulk-media-uploader-test.php';
}
