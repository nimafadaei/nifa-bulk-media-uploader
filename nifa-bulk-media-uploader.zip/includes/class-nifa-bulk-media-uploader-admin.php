<?php
/**
 * Admin class
 *
 * @package Nifa_Bulk_Media_Uploader
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin class
 */
class Nifa_Bulk_Media_Uploader_Admin {
    /**
     * Parent plugin instance
     *
     * @var Nifa_Bulk_Media_Uploader
     */
    private $plugin;

    /**
     * Constructor
     *
     * @param Nifa_Bulk_Media_Uploader $plugin Parent plugin instance.
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
    }

    /**
     * Initialize admin
     */
    public function init() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Register admin scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'register_admin_scripts_styles'));

        // Register settings
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Add main menu item
        add_menu_page(
            __('Nifa Bulk Media Uploader', 'nifa-bulk-media-uploader'),
            __('Bulk Media Uploader', 'nifa-bulk-media-uploader'),
            'upload_files',
            'nifa-bulk-media-uploader',
            array($this, 'render_main_page'),
            'dashicons-upload',
            30
        );

        // Add settings submenu
        add_submenu_page(
            'nifa-bulk-media-uploader',
            __('Settings', 'nifa-bulk-media-uploader'),
            __('Settings', 'nifa-bulk-media-uploader'),
            'manage_options',
            'nifa-bulk-media-uploader-settings',
            array($this, 'render_settings_page')
        );

        // Rename the first submenu item
        global $submenu;
        if (isset($submenu['nifa-bulk-media-uploader'])) {
            $submenu['nifa-bulk-media-uploader'][0][0] = __('Upload Media', 'nifa-bulk-media-uploader');
        }
    }

    /**
     * Register admin scripts and styles
     *
     * @param string $hook Current admin page hook.
     */
    public function register_admin_scripts_styles($hook) {
        // Only load on plugin pages
        if (strpos($hook, 'nifa-bulk-media-uploader') === false) {
            return;
        }

        // Register and enqueue styles
        wp_register_style(
            'nifa-bmu-admin-styles',
            NIFA_BMU_PLUGIN_URL . 'assets/css/nifa-bmu-admin.css',
            array(),
            NIFA_BMU_VERSION
        );
        wp_enqueue_style('nifa-bmu-admin-styles');

        // Register and enqueue scripts
        wp_register_script(
            'nifa-bmu-admin-scripts',
            NIFA_BMU_PLUGIN_URL . 'assets/js/nifa-bmu-admin.js',
            array('jquery'),
            NIFA_BMU_VERSION,
            true
        );
        
        // Localize script with plugin data
        wp_localize_script('nifa-bmu-admin-scripts', 'nifa_bmu_data', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => array(
                'upload' => wp_create_nonce('nifa_bmu_upload_nonce'),
                'process' => wp_create_nonce('nifa_bmu_process_nonce'),
            ),
            'strings' => array(
                'uploading' => __('Uploading...', 'nifa-bulk-media-uploader'),
                'processing' => __('Processing...', 'nifa-bulk-media-uploader'),
                'completed' => __('Completed', 'nifa-bulk-media-uploader'),
                'error' => __('Error', 'nifa-bulk-media-uploader'),
                'confirm_cancel' => __('Are you sure you want to cancel the upload?', 'nifa-bulk-media-uploader'),
            ),
            'settings' => $this->plugin->get_settings(),
        ));
        
        wp_enqueue_script('nifa-bmu-admin-scripts');
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting(
            'nifa_bmu_settings',
            'nifa_bmu_settings',
            array($this, 'sanitize_settings')
        );

        // Add settings sections
        add_settings_section(
            'nifa_bmu_general_section',
            __('General Settings', 'nifa-bulk-media-uploader'),
            array($this, 'render_general_section'),
            'nifa_bmu_settings'
        );

        add_settings_section(
            'nifa_bmu_file_section',
            __('File Settings', 'nifa-bulk-media-uploader'),
            array($this, 'render_file_section'),
            'nifa_bmu_settings'
        );

        add_settings_section(
            'nifa_bmu_advanced_section',
            __('Advanced Settings', 'nifa-bulk-media-uploader'),
            array($this, 'render_advanced_section'),
            'nifa_bmu_settings'
        );

        // Add settings fields
        // General section
        add_settings_field(
            'max_file_size',
            __('Maximum ZIP File Size (MB)', 'nifa-bulk-media-uploader'),
            array($this, 'render_max_file_size_field'),
            'nifa_bmu_settings',
            'nifa_bmu_general_section'
        );

        add_settings_field(
            'auto_organize',
            __('Auto-Organize Uploads', 'nifa-bulk-media-uploader'),
            array($this, 'render_auto_organize_field'),
            'nifa_bmu_settings',
            'nifa_bmu_general_section'
        );

        // File section
        add_settings_field(
            'allowed_file_types',
            __('Allowed File Types', 'nifa-bulk-media-uploader'),
            array($this, 'render_allowed_file_types_field'),
            'nifa_bmu_settings',
            'nifa_bmu_file_section'
        );

        // Advanced section
        add_settings_field(
            'process_limit',
            __('Files Per Batch', 'nifa-bulk-media-uploader'),
            array($this, 'render_process_limit_field'),
            'nifa_bmu_settings',
            'nifa_bmu_advanced_section'
        );
    }

    /**
     * Sanitize settings
     *
     * @param array $input Settings input.
     * @return array Sanitized settings.
     */
    public function sanitize_settings($input) {
        $sanitized = array();

        // Sanitize max_file_size
        $sanitized['max_file_size'] = isset($input['max_file_size']) ? absint($input['max_file_size']) : 50;
        if ($sanitized['max_file_size'] < 1) {
            $sanitized['max_file_size'] = 1;
        }

        // Sanitize auto_organize
        $sanitized['auto_organize'] = isset($input['auto_organize']) && $input['auto_organize'] ? true : false;

        // Sanitize allowed_file_types
        $default_file_types = array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv');
        $sanitized['allowed_file_types'] = isset($input['allowed_file_types']) && is_array($input['allowed_file_types']) ? $input['allowed_file_types'] : $default_file_types;
        
        // Make sure all file types are valid
        $sanitized['allowed_file_types'] = array_filter($sanitized['allowed_file_types'], function($type) {
            return preg_match('/^[a-z0-9]+$/', $type);
        });

        // Sanitize process_limit
        $sanitized['process_limit'] = isset($input['process_limit']) ? absint($input['process_limit']) : 20;
        if ($sanitized['process_limit'] < 1) {
            $sanitized['process_limit'] = 1;
        } elseif ($sanitized['process_limit'] > 100) {
            $sanitized['process_limit'] = 100;
        }

        return $sanitized;
    }

    /**
     * Render general section
     */
    public function render_general_section() {
        echo '<p>' . __('Configure general settings for the bulk media uploader.', 'nifa-bulk-media-uploader') . '</p>';
    }

    /**
     * Render file section
     */
    public function render_file_section() {
        echo '<p>' . __('Configure file settings for the bulk media uploader.', 'nifa-bulk-media-uploader') . '</p>';
    }

    /**
     * Render advanced section
     */
    public function render_advanced_section() {
        echo '<p>' . __('Configure advanced settings for the bulk media uploader.', 'nifa-bulk-media-uploader') . '</p>';
    }

    /**
     * Render max file size field
     */
    public function render_max_file_size_field() {
        $settings = $this->plugin->get_settings();
        $max_file_size = isset($settings['max_file_size']) ? $settings['max_file_size'] : 50;
        ?>
        <input type="number" name="nifa_bmu_settings[max_file_size]" value="<?php echo esc_attr($max_file_size); ?>" min="1" step="1" class="small-text" />
        <p class="description"><?php _e('Maximum size of ZIP files that can be uploaded (in MB).', 'nifa-bulk-media-uploader'); ?></p>
        <?php
    }

    /**
     * Render auto organize field
     */
    public function render_auto_organize_field() {
        $settings = $this->plugin->get_settings();
        $auto_organize = isset($settings['auto_organize']) ? $settings['auto_organize'] : true;
        ?>
        <label>
            <input type="checkbox" name="nifa_bmu_settings[auto_organize]" value="1" <?php checked($auto_organize, true); ?> />
            <?php _e('Automatically organize uploads by date', 'nifa-bulk-media-uploader'); ?>
        </label>
        <p class="description"><?php _e('If enabled, uploaded media files will be organized into year/month folders.', 'nifa-bulk-media-uploader'); ?></p>
        <?php
    }

    /**
     * Render allowed file types field
     */
    public function render_allowed_file_types_field() {
        $settings = $this->plugin->get_settings();
        $allowed_file_types = isset($settings['allowed_file_types']) ? $settings['allowed_file_types'] : array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv');
        
        $all_file_types = array(
            'jpg' => __('JPEG Image (.jpg)', 'nifa-bulk-media-uploader'),
            'jpeg' => __('JPEG Image (.jpeg)', 'nifa-bulk-media-uploader'),
            'png' => __('PNG Image (.png)', 'nifa-bulk-media-uploader'),
            'gif' => __('GIF Image (.gif)', 'nifa-bulk-media-uploader'),
            'webp' => __('WebP Image (.webp)', 'nifa-bulk-media-uploader'),
            'mp4' => __('MP4 Video (.mp4)', 'nifa-bulk-media-uploader'),
            'mov' => __('QuickTime Video (.mov)', 'nifa-bulk-media-uploader'),
            'avi' => __('AVI Video (.avi)', 'nifa-bulk-media-uploader'),
            'wmv' => __('Windows Media Video (.wmv)', 'nifa-bulk-media-uploader'),
            'webm' => __('WebM Video (.webm)', 'nifa-bulk-media-uploader'),
        );
        
        foreach ($all_file_types as $type => $label) {
            $checked = in_array($type, $allowed_file_types) ? 'checked' : '';
            echo '<label style="display: block; margin-bottom: 5px;">';
            echo '<input type="checkbox" name="nifa_bmu_settings[allowed_file_types][]" value="' . esc_attr($type) . '" ' . $checked . ' />';
            echo ' ' . esc_html($label);
            echo '</label>';
        }
        
        echo '<p class="description">' . __('Select the file types that can be uploaded through the bulk uploader.', 'nifa-bulk-media-uploader') . '</p>';
    }

    /**
     * Render process limit field
     */
    public function render_process_limit_field() {
        $settings = $this->plugin->get_settings();
        $process_limit = isset($settings['process_limit']) ? $settings['process_limit'] : 20;
        ?>
        <input type="number" name="nifa_bmu_settings[process_limit]" value="<?php echo esc_attr($process_limit); ?>" min="1" max="100" step="1" class="small-text" />
        <p class="description"><?php _e('Number of files to process per batch. Higher values may improve speed but could cause timeouts on some servers.', 'nifa-bulk-media-uploader'); ?></p>
        <?php
    }

    /**
     * Render main page
     */
    public function render_main_page() {
        ?>
        <div class="wrap nifa-bmu-wrap">
            <h1><?php _e('Nifa Bulk Media Uploader', 'nifa-bulk-media-uploader'); ?></h1>
            
            <div class="nifa-bmu-container">
                <div class="nifa-bmu-upload-section">
                    <h2><?php _e('Upload ZIP File', 'nifa-bulk-media-uploader'); ?></h2>
                    
                    <p><?php _e('Upload a ZIP file containing images and videos to add them to your media library.', 'nifa-bulk-media-uploader'); ?></p>
                    
                    <form id="nifa-bmu-upload-form" method="post" enctype="multipart/form-data">
                        <div class="nifa-bmu-upload-field">
                            <label for="nifa-bmu-zip-file" class="nifa-bmu-upload-label">
                                <span class="dashicons dashicons-upload"></span>
                                <span class="nifa-bmu-upload-text"><?php _e('Choose ZIP file or drag it here', 'nifa-bulk-media-uploader'); ?></span>
                            </label>
                            <input type="file" name="zip_file" id="nifa-bmu-zip-file" accept=".zip" />
                        </div>
                        
                        <div class="nifa-bmu-file-info" style="display: none;">
                            <div class="nifa-bmu-file-name"></div>
                            <div class="nifa-bmu-file-size"></div>
                            <button type="button" class="nifa-bmu-remove-file button"><?php _e('Remove', 'nifa-bulk-media-uploader'); ?></button>
                        </div>
                        
                        <div class="nifa-bmu-progress" style="display: none;">
                            <div class="nifa-bmu-progress-bar">
                                <div class="nifa-bmu-progress-bar-inner"></div>
                            </div>
                            <div class="nifa-bmu-progress-text">0%</div>
                            <button type="button" class="nifa-bmu-cancel-upload button"><?php _e('Cancel', 'nifa-bulk-media-uploader'); ?></button>
                        </div>
                        
                        <div class="nifa-bmu-actions">
                            <button type="submit" class="nifa-bmu-upload-button button button-primary"><?php _e('Upload and Process', 'nifa-bulk-media-uploader'); ?></button>
                        </div>
                    </form>
                </div>
                
                <div class="nifa-bmu-results" style="display: none;">
                    <h2><?php _e('Upload Results', 'nifa-bulk-media-uploader'); ?></h2>
                    
                    <div class="nifa-bmu-results-summary"></div>
                    
                    <div class="nifa-bmu-results-details">
                        <h3><?php _e('Details', 'nifa-bulk-media-uploader'); ?></h3>
                        <div class="nifa-bmu-results-errors"></div>
                    </div>
                    
                    <div class="nifa-bmu-results-actions">
                        <a href="<?php echo esc_url(admin_url('upload.php')); ?>" class="button button-secondary"><?php _e('Go to Media Library', 'nifa-bulk-media-uploader'); ?></a>
                        <button type="button" class="nifa-bmu-new-upload button button-primary"><?php _e('Upload Another ZIP File', 'nifa-bulk-media-uploader'); ?></button>
                    </div>
                </div>
            </div>
            
            <div class="nifa-bmu-info">
                <h3><?php _e('Instructions', 'nifa-bulk-media-uploader'); ?></h3>
                <ol>
                    <li><?php _e('Create a ZIP file containing the images and videos you want to upload.', 'nifa-bulk-media-uploader'); ?></li>
                    <li><?php _e('Click the upload area above or drag your ZIP file into it.', 'nifa-bulk-media-uploader'); ?></li>
                    <li><?php _e('Click "Upload and Process" to start the upload process.', 'nifa-bulk-media-uploader'); ?></li>
                    <li><?php _e('Wait for the upload and processing to complete.', 'nifa-bulk-media-uploader'); ?></li>
                    <li><?php _e('All media files will be added to your WordPress media library.', 'nifa-bulk-media-uploader'); ?></li>
                </ol>
                
                <h3><?php _e('Supported File Types', 'nifa-bulk-media-uploader'); ?></h3>
                <p>
                    <?php 
                    $settings = $this->plugin->get_settings();
                    $allowed_file_types = isset($settings['allowed_file_types']) ? $settings['allowed_file_types'] : array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv');
                    echo esc_html(implode(', ', array_map(function($type) { return '.' . $type; }, $allowed_file_types)));
                    ?>
                </p>
                
                <h3><?php _e('Maximum File Size', 'nifa-bulk-media-uploader'); ?></h3>
                <p>
                    <?php 
                    $max_file_size = isset($settings['max_file_size']) ? $settings['max_file_size'] : 50;
                    printf(__('ZIP files up to %d MB are allowed.', 'nifa-bulk-media-uploader'), $max_file_size);
                    ?>
                </p>
            </div>
            
            <div class="nifa-bmu-footer">
                <p>
                    <?php printf(__('Nifa Bulk Media Uploader v%s by %s', 'nifa-bulk-media-uploader'), NIFA_BMU_VERSION, '<a href="https://nifaweb.site" target="_blank">Nima Fadaei</a>'); ?>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        ?>
        <div class="wrap nifa-bmu-wrap">
            <h1><?php _e('Nifa Bulk Media Uploader Settings', 'nifa-bulk-media-uploader'); ?></h1>
            
            <form method="post" action="options.php" class="nifa-bmu-settings-form">
                <?php
                settings_fields('nifa_bmu_settings');
                do_settings_sections('nifa_bmu_settings');
                submit_button();
                ?>
            </form>
            
            <div class="nifa-bmu-footer">
                <p>
                    <?php printf(__('Nifa Bulk Media Uploader v%s by %s', 'nifa-bulk-media-uploader'), NIFA_BMU_VERSION, '<a href="https://nifaweb.site" target="_blank">Nima Fadaei</a>'); ?>
                </p>
            </div>
        </div>
        <?php
    }
}
