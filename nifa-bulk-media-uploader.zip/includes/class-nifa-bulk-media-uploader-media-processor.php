<?php
/**
 * Media Processor class
 *
 * @package Nifa_Bulk_Media_Uploader
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Media Processor class
 */
class Nifa_Bulk_Media_Uploader_Media_Processor {
    /**
     * Parent plugin instance
     *
     * @var Nifa_Bulk_Media_Uploader
     */
    private $plugin;

    /**
     * Settings
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor
     *
     * @param Nifa_Bulk_Media_Uploader $plugin Parent plugin instance.
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->settings = $plugin->get_settings();
    }

    /**
     * Process media file
     *
     * @param string $file_path Path to media file.
     * @param string $file_name Original file name.
     * @return int|WP_Error Attachment ID on success, WP_Error on failure.
     */
    public function process_media_file($file_path, $file_name) {
        // Check if file exists
        if (!file_exists($file_path)) {
            return new WP_Error('file_not_found', __('File not found.', 'nifa-bulk-media-uploader'));
        }

        // Check file type
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_file_types = isset($this->settings['allowed_file_types']) ? $this->settings['allowed_file_types'] : array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv');
        
        if (!in_array($file_ext, $allowed_file_types)) {
            return new WP_Error('invalid_file_type', sprintf(__('File type %s is not allowed.', 'nifa-bulk-media-uploader'), $file_ext));
        }

        // Upload to media library
        return $this->upload_to_media_library($file_path, $file_name);
    }

    /**
     * Upload file to media library
     *
     * @param string $file_path File path.
     * @param string $file_name File name.
     * @return int|WP_Error Attachment ID on success, WP_Error on failure.
     */
    private function upload_to_media_library($file_path, $file_name) {
        // Get file type
        $file_type = wp_check_filetype($file_name, null);
        if (empty($file_type['type'])) {
            return new WP_Error('invalid_file_type', __('Invalid file type.', 'nifa-bulk-media-uploader'));
        }

        // Prepare upload directory
        $upload_dir = wp_upload_dir();
        
        // Check if auto-organize is enabled
        $auto_organize = isset($this->settings['auto_organize']) ? $this->settings['auto_organize'] : true;
        
        // Determine upload path
        if ($auto_organize) {
            // Use WordPress default year/month organization
            $upload_path = $upload_dir['path'] . '/' . wp_unique_filename($upload_dir['path'], $file_name);
        } else {
            // Use uploads directory without year/month organization
            $upload_path = $upload_dir['basedir'] . '/' . wp_unique_filename($upload_dir['basedir'], $file_name);
        }
        
        // Copy file to uploads directory
        if (!copy($file_path, $upload_path)) {
            return new WP_Error('copy_error', __('Failed to copy file to uploads directory.', 'nifa-bulk-media-uploader'));
        }
        
        // Prepare attachment data
        $attachment = array(
            'guid' => $upload_dir['url'] . '/' . basename($upload_path),
            'post_mime_type' => $file_type['type'],
            'post_title' => preg_replace('/\.[^.]+$/', '', $file_name),
            'post_content' => '',
            'post_status' => 'inherit',
        );
        
        // Insert attachment
        $attachment_id = wp_insert_attachment($attachment, $upload_path);
        
        if (is_wp_error($attachment_id)) {
            @unlink($upload_path);
            return $attachment_id;
        }
        
        // Include image.php for media handling functions
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Generate attachment metadata
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_path);
        
        // Update attachment metadata
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        return $attachment_id;
    }

    /**
     * Process image optimizations
     *
     * @param int $attachment_id Attachment ID.
     * @return bool True on success, false on failure.
     */
    public function optimize_image($attachment_id) {
        // Get attachment metadata
        $attachment_metadata = wp_get_attachment_metadata($attachment_id);
        
        if (!$attachment_metadata || !isset($attachment_metadata['file'])) {
            return false;
        }
        
        // Get file path
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/' . $attachment_metadata['file'];
        
        if (!file_exists($file_path)) {
            return false;
        }
        
        // Check if file is an image
        $image_mime_types = array('image/jpeg', 'image/png', 'image/gif', 'image/webp');
        $file_type = wp_check_filetype($file_path, null);
        
        if (!in_array($file_type['type'], $image_mime_types)) {
            return false;
        }
        
        // Basic image optimization
        // This is a placeholder for potential image optimization functionality
        // In a real-world scenario, you might want to use libraries like Imagick or GD
        // to perform actual image optimization
        
        return true;
    }

    /**
     * Generate video thumbnail
     *
     * @param int $attachment_id Attachment ID.
     * @return bool True on success, false on failure.
     */
    public function generate_video_thumbnail($attachment_id) {
        // Get attachment metadata
        $attachment_metadata = wp_get_attachment_metadata($attachment_id);
        
        if (!$attachment_metadata || !isset($attachment_metadata['file'])) {
            return false;
        }
        
        // Get file path
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/' . $attachment_metadata['file'];
        
        if (!file_exists($file_path)) {
            return false;
        }
        
        // Check if file is a video
        $video_mime_types = array('video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/x-ms-wmv', 'video/webm');
        $file_type = wp_check_filetype($file_path, null);
        
        if (!in_array($file_type['type'], $video_mime_types)) {
            return false;
        }
        
        // Video thumbnail generation
        // This is a placeholder for potential video thumbnail generation functionality
        // In a real-world scenario, you might want to use FFmpeg or other video processing
        // libraries to generate thumbnails from videos
        
        return true;
    }
}
