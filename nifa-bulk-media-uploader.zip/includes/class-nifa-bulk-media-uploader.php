<?php
/**
 * Main plugin class
 *
 * @package Nifa_Bulk_Media_Uploader
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main plugin class
 */
class Nifa_Bulk_Media_Uploader {
    /**
     * Plugin instance
     *
     * @var Nifa_Bulk_Media_Uploader
     */
    private static $instance = null;

    /**
     * Admin class instance
     *
     * @var Nifa_Bulk_Media_Uploader_Admin
     */
    public $admin;

    /**
     * Plugin settings
     *
     * @var array
     */
    private $settings;

    /**
     * Constructor
     */
    public function __construct() {
        $this->settings = get_option('nifa_bmu_settings', array());
    }

    /**
     * Get plugin instance
     *
     * @return Nifa_Bulk_Media_Uploader
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize plugin
     */
    public function init() {
        // Initialize admin
        if (is_admin()) {
            $this->admin = new Nifa_Bulk_Media_Uploader_Admin($this);
            $this->admin->init();
        }

        // Add plugin action links
        add_filter('plugin_action_links_' . NIFA_BMU_PLUGIN_BASENAME, array($this, 'add_plugin_action_links'));

        // Register scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'register_scripts_styles'));
        
        // Add AJAX handlers
        add_action('wp_ajax_nifa_bmu_upload_zip', array($this, 'handle_zip_upload'));
        add_action('wp_ajax_nifa_bmu_process_zip', array($this, 'process_zip_file'));
    }

    /**
     * Register scripts and styles
     */
    public function register_scripts_styles() {
        // Register styles
        wp_register_style(
            'nifa-bmu-styles',
            NIFA_BMU_PLUGIN_URL . 'assets/css/nifa-bmu-styles.css',
            array(),
            NIFA_BMU_VERSION
        );

        // Register scripts
        wp_register_script(
            'nifa-bmu-scripts',
            NIFA_BMU_PLUGIN_URL . 'assets/js/nifa-bmu-scripts.js',
            array('jquery'),
            NIFA_BMU_VERSION,
            true
        );
    }

    /**
     * Add plugin action links
     *
     * @param array $links Plugin action links.
     * @return array Modified plugin action links.
     */
    public function add_plugin_action_links($links) {
        $plugin_links = array(
            '<a href="' . admin_url('admin.php?page=nifa-bulk-media-uploader') . '">' . __('Settings', 'nifa-bulk-media-uploader') . '</a>',
        );
        return array_merge($plugin_links, $links);
    }

    /**
     * Handle ZIP file upload via AJAX
     */
    public function handle_zip_upload() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'nifa_bmu_upload_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'nifa-bulk-media-uploader')));
        }

        // Check user capabilities
        if (!current_user_can('upload_files')) {
            wp_send_json_error(array('message' => __('You do not have permission to upload files.', 'nifa-bulk-media-uploader')));
        }

        // Check if file was uploaded
        if (empty($_FILES['zip_file'])) {
            wp_send_json_error(array('message' => __('No file was uploaded.', 'nifa-bulk-media-uploader')));
        }

        $file = $_FILES['zip_file'];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $error_message = $this->get_upload_error_message($file['error']);
            wp_send_json_error(array('message' => $error_message));
        }

        // Check file type
        $file_type = wp_check_filetype(basename($file['name']), array('zip' => 'application/zip'));
        if (empty($file_type['type'])) {
            wp_send_json_error(array('message' => __('Invalid file type. Only ZIP files are allowed.', 'nifa-bulk-media-uploader')));
        }

        // Get upload directory
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/nifa-bmu-temp';

        // Create temp directory if it doesn't exist
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }

        // Generate unique filename
        $filename = wp_unique_filename($temp_dir, $file['name']);
        $file_path = $temp_dir . '/' . $filename;

        // Move uploaded file to temp directory
        if (!move_uploaded_file($file['tmp_name'], $file_path)) {
            wp_send_json_error(array('message' => __('Failed to upload file.', 'nifa-bulk-media-uploader')));
        }

        // Return success response with file path
        wp_send_json_success(array(
            'message' => __('File uploaded successfully.', 'nifa-bulk-media-uploader'),
            'file_path' => $file_path,
            'file_name' => basename($file['name']),
        ));
    }

    /**
     * Process ZIP file and extract media files
     */
    public function process_zip_file() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'nifa_bmu_process_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed.', 'nifa-bulk-media-uploader')));
        }

        // Check user capabilities
        if (!current_user_can('upload_files')) {
            wp_send_json_error(array('message' => __('You do not have permission to upload files.', 'nifa-bulk-media-uploader')));
        }

        // Check if file path is provided
        if (empty($_POST['file_path'])) {
            wp_send_json_error(array('message' => __('No file path provided.', 'nifa-bulk-media-uploader')));
        }

        $file_path = sanitize_text_field($_POST['file_path']);
        $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
        $settings = $this->get_settings();
        $process_limit = isset($settings['process_limit']) ? intval($settings['process_limit']) : 20;

        // Check if file exists
        if (!file_exists($file_path)) {
            wp_send_json_error(array('message' => __('File not found.', 'nifa-bulk-media-uploader')));
        }

        // Create ZipArchive instance
        $zip = new ZipArchive();
        if ($zip->open($file_path) !== true) {
            wp_send_json_error(array('message' => __('Failed to open ZIP file.', 'nifa-bulk-media-uploader')));
        }

        // Get total number of files in ZIP
        $total_files = $zip->numFiles;
        $processed_files = 0;
        $uploaded_files = 0;
        $skipped_files = 0;
        $errors = array();

        // Get allowed file types
        $allowed_file_types = isset($settings['allowed_file_types']) ? $settings['allowed_file_types'] : array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv');

        // Process files
        for ($i = $offset; $i < min($total_files, $offset + $process_limit); $i++) {
            $file_info = $zip->statIndex($i);
            $file_name = $file_info['name'];
            
            // Skip directories
            if (substr($file_name, -1) === '/') {
                $processed_files++;
                continue;
            }

            // Check file extension
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            if (!in_array($file_ext, $allowed_file_types)) {
                $skipped_files++;
                $processed_files++;
                continue;
            }

            // Extract file to temporary location
            $temp_file = get_temp_dir() . basename($file_name);
            if (copy('zip://' . $file_path . '#' . $file_name, $temp_file)) {
                // Upload file to media library
                $upload_result = $this->upload_to_media_library($temp_file, basename($file_name));
                
                if (is_wp_error($upload_result)) {
                    $errors[] = sprintf(__('Failed to upload %s: %s', 'nifa-bulk-media-uploader'), basename($file_name), $upload_result->get_error_message());
                } else {
                    $uploaded_files++;
                }
                
                // Remove temporary file
                @unlink($temp_file);
            } else {
                $errors[] = sprintf(__('Failed to extract %s from ZIP file.', 'nifa-bulk-media-uploader'), basename($file_name));
            }
            
            $processed_files++;
        }

        // Check if all files have been processed
        $is_completed = ($offset + $processed_files) >= $total_files;
        
        // Close ZIP file
        $zip->close();
        
        // Remove ZIP file if processing is completed
        if ($is_completed) {
            @unlink($file_path);
        }

        // Return response
        wp_send_json_success(array(
            'message' => sprintf(__('Processed %d files, uploaded %d files, skipped %d files.', 'nifa-bulk-media-uploader'), $processed_files, $uploaded_files, $skipped_files),
            'processed' => $processed_files,
            'uploaded' => $uploaded_files,
            'skipped' => $skipped_files,
            'errors' => $errors,
            'offset' => $offset + $processed_files,
            'total' => $total_files,
            'is_completed' => $is_completed,
        ));
    }

    /**
     * Upload file to media library
     *
     * @param string $file_path File path.
     * @param string $file_name File name.
     * @return int|WP_Error Attachment ID on success, WP_Error on failure.
     */
    private function upload_to_media_library($file_path, $file_name) {
        // Get file type
        $file_type = wp_check_filetype($file_name, null);
        
        // Prepare attachment data
        $attachment = array(
            'post_mime_type' => $file_type['type'],
            'post_title' => preg_replace('/\.[^.]+$/', '', $file_name),
            'post_content' => '',
            'post_status' => 'inherit',
        );
        
        // Insert attachment
        $attachment_id = wp_insert_attachment($attachment, $file_path);
        
        if (!is_wp_error($attachment_id)) {
            // Include image.php for media handling functions
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            
            // Generate attachment metadata
            $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
            
            // Update attachment metadata
            wp_update_attachment_metadata($attachment_id, $attachment_data);
            
            return $attachment_id;
        }
        
        return $attachment_id;
    }

    /**
     * Get upload error message
     *
     * @param int $error_code Error code.
     * @return string Error message.
     */
    private function get_upload_error_message($error_code) {
        switch ($error_code) {
            case UPLOAD_ERR_INI_SIZE:
                return __('The uploaded file exceeds the upload_max_filesize directive in php.ini.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_FORM_SIZE:
                return __('The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_PARTIAL:
                return __('The uploaded file was only partially uploaded.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_NO_FILE:
                return __('No file was uploaded.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_NO_TMP_DIR:
                return __('Missing a temporary folder.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_CANT_WRITE:
                return __('Failed to write file to disk.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_EXTENSION:
                return __('A PHP extension stopped the file upload.', 'nifa-bulk-media-uploader');
            default:
                return __('Unknown upload error.', 'nifa-bulk-media-uploader');
        }
    }

    /**
     * Get plugin settings
     *
     * @return array Plugin settings.
     */
    public function get_settings() {
        return $this->settings;
    }

    /**
     * Update plugin settings
     *
     * @param array $settings New settings.
     * @return bool True on success, false on failure.
     */
    public function update_settings($settings) {
        $this->settings = $settings;
        return update_option('nifa_bmu_settings', $settings);
    }
}
