<?php
/**
 * Class for handling ZIP file uploads and processing
 *
 * @package Nifa_Bulk_Media_Uploader
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ZIP Handler class
 */
class Nifa_Bulk_Media_Uploader_ZIP_Handler {
    /**
     * Parent plugin instance
     *
     * @var Nifa_Bulk_Media_Uploader
     */
    private $plugin;

    /**
     * Settings
     *
     * @var array
     */
    private $settings;

    /**
     * Temporary directory
     *
     * @var string
     */
    private $temp_dir;

    /**
     * Constructor
     *
     * @param Nifa_Bulk_Media_Uploader $plugin Parent plugin instance.
     */
    public function __construct($plugin) {
        $this->plugin = $plugin;
        $this->settings = $plugin->get_settings();
        
        // Set up temporary directory
        $upload_dir = wp_upload_dir();
        $this->temp_dir = $upload_dir['basedir'] . '/nifa-bmu-temp';
        
        // Create temp directory if it doesn't exist
        if (!file_exists($this->temp_dir)) {
            wp_mkdir_p($this->temp_dir);
        }
        
        // Add index.php to prevent directory listing
        if (!file_exists($this->temp_dir . '/index.php')) {
            file_put_contents($this->temp_dir . '/index.php', '<?php // Silence is golden');
        }
        
        // Add .htaccess to prevent direct access
        if (!file_exists($this->temp_dir . '/.htaccess')) {
            file_put_contents($this->temp_dir . '/.htaccess', 'deny from all');
        }
    }

    /**
     * Handle ZIP file upload
     *
     * @return array|WP_Error Response data or error.
     */
    public function handle_upload() {
        // Check if file was uploaded
        if (empty($_FILES['zip_file'])) {
            return new WP_Error('no_file', __('No file was uploaded.', 'nifa-bulk-media-uploader'));
        }

        $file = $_FILES['zip_file'];

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $error_message = $this->get_upload_error_message($file['error']);
            return new WP_Error('upload_error', $error_message);
        }

        // Check file type
        $file_type = wp_check_filetype(basename($file['name']), array('zip' => 'application/zip'));
        if (empty($file_type['type'])) {
            return new WP_Error('invalid_type', __('Invalid file type. Only ZIP files are allowed.', 'nifa-bulk-media-uploader'));
        }

        // Check file size
        $max_size = $this->settings['max_file_size'] * 1024 * 1024; // Convert MB to bytes
        if ($file['size'] > $max_size) {
            return new WP_Error('file_too_large', sprintf(__('File size exceeds the maximum allowed size of %d MB.', 'nifa-bulk-media-uploader'), $this->settings['max_file_size']));
        }

        // Generate unique filename
        $filename = wp_unique_filename($this->temp_dir, $file['name']);
        $file_path = $this->temp_dir . '/' . $filename;

        // Move uploaded file to temp directory
        if (!move_uploaded_file($file['tmp_name'], $file_path)) {
            return new WP_Error('move_error', __('Failed to upload file.', 'nifa-bulk-media-uploader'));
        }

        // Check if file is a valid ZIP archive
        if (!$this->is_valid_zip($file_path)) {
            @unlink($file_path);
            return new WP_Error('invalid_zip', __('The uploaded file is not a valid ZIP archive.', 'nifa-bulk-media-uploader'));
        }

        // Return success response
        return array(
            'file_path' => $file_path,
            'file_name' => basename($file['name']),
            'file_size' => $file['size'],
        );
    }

    /**
     * Process ZIP file
     *
     * @param string $file_path Path to ZIP file.
     * @param int    $offset    Offset for batch processing.
     * @return array|WP_Error Response data or error.
     */
    public function process_zip($file_path, $offset = 0) {
        // Check if file exists
        if (!file_exists($file_path)) {
            return new WP_Error('file_not_found', __('File not found.', 'nifa-bulk-media-uploader'));
        }

        // Check if file is a valid ZIP archive
        if (!$this->is_valid_zip($file_path)) {
            return new WP_Error('invalid_zip', __('The file is not a valid ZIP archive.', 'nifa-bulk-media-uploader'));
        }

        // Get process limit from settings
        $process_limit = isset($this->settings['process_limit']) ? intval($this->settings['process_limit']) : 20;

        // Create ZipArchive instance
        $zip = new ZipArchive();
        if ($zip->open($file_path) !== true) {
            return new WP_Error('zip_open_error', __('Failed to open ZIP file.', 'nifa-bulk-media-uploader'));
        }

        // Get total number of files in ZIP
        $total_files = $zip->numFiles;
        $processed_files = 0;
        $uploaded_files = 0;
        $skipped_files = 0;
        $errors = array();

        // Get allowed file types
        $allowed_file_types = isset($this->settings['allowed_file_types']) ? $this->settings['allowed_file_types'] : array('jpg', 'jpeg', 'png', 'gif', 'mp4', 'mov', 'avi', 'wmv');

        // Process files
        for ($i = $offset; $i < min($total_files, $offset + $process_limit); $i++) {
            $file_info = $zip->statIndex($i);
            $file_name = $file_info['name'];
            
            // Skip directories
            if (substr($file_name, -1) === '/') {
                $processed_files++;
                continue;
            }

            // Check file extension
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            if (!in_array($file_ext, $allowed_file_types)) {
                $skipped_files++;
                $processed_files++;
                continue;
            }

            // Extract file to temporary location
            $temp_file = $this->temp_dir . '/' . wp_unique_filename($this->temp_dir, basename($file_name));
            
            // Get file contents from ZIP
            $file_contents = $zip->getFromIndex($i);
            if ($file_contents === false) {
                $errors[] = sprintf(__('Failed to extract %s from ZIP file.', 'nifa-bulk-media-uploader'), basename($file_name));
                $processed_files++;
                continue;
            }
            
            // Write file contents to temporary file
            if (file_put_contents($temp_file, $file_contents) === false) {
                $errors[] = sprintf(__('Failed to write %s to temporary file.', 'nifa-bulk-media-uploader'), basename($file_name));
                $processed_files++;
                continue;
            }
            
            // Upload file to media library
            $upload_result = $this->upload_to_media_library($temp_file, basename($file_name));
            
            if (is_wp_error($upload_result)) {
                $errors[] = sprintf(__('Failed to upload %s: %s', 'nifa-bulk-media-uploader'), basename($file_name), $upload_result->get_error_message());
            } else {
                $uploaded_files++;
            }
            
            // Remove temporary file
            @unlink($temp_file);
            
            $processed_files++;
        }

        // Check if all files have been processed
        $is_completed = ($offset + $processed_files) >= $total_files;
        
        // Close ZIP file
        $zip->close();
        
        // Remove ZIP file if processing is completed
        if ($is_completed) {
            @unlink($file_path);
        }

        // Return response
        return array(
            'message' => sprintf(__('Processed %d files, uploaded %d files, skipped %d files.', 'nifa-bulk-media-uploader'), $processed_files, $uploaded_files, $skipped_files),
            'processed' => $processed_files,
            'uploaded' => $uploaded_files,
            'skipped' => $skipped_files,
            'errors' => $errors,
            'offset' => $offset + $processed_files,
            'total' => $total_files,
            'is_completed' => $is_completed,
        );
    }

    /**
     * Upload file to media library
     *
     * @param string $file_path File path.
     * @param string $file_name File name.
     * @return int|WP_Error Attachment ID on success, WP_Error on failure.
     */
    private function upload_to_media_library($file_path, $file_name) {
        // Check if file exists
        if (!file_exists($file_path)) {
            return new WP_Error('file_not_found', __('File not found.', 'nifa-bulk-media-uploader'));
        }

        // Get file type
        $file_type = wp_check_filetype($file_name, null);
        if (empty($file_type['type'])) {
            return new WP_Error('invalid_file_type', __('Invalid file type.', 'nifa-bulk-media-uploader'));
        }

        // Prepare upload directory
        $upload_dir = wp_upload_dir();
        
        // Check if auto-organize is enabled
        $auto_organize = isset($this->settings['auto_organize']) ? $this->settings['auto_organize'] : true;
        
        // Determine upload path
        if ($auto_organize) {
            // Use WordPress default year/month organization
            $upload_path = $upload_dir['path'] . '/' . wp_unique_filename($upload_dir['path'], $file_name);
        } else {
            // Use uploads directory without year/month organization
            $upload_path = $upload_dir['basedir'] . '/' . wp_unique_filename($upload_dir['basedir'], $file_name);
        }
        
        // Copy file to uploads directory
        if (!copy($file_path, $upload_path)) {
            return new WP_Error('copy_error', __('Failed to copy file to uploads directory.', 'nifa-bulk-media-uploader'));
        }
        
        // Prepare attachment data
        $attachment = array(
            'guid' => $upload_dir['url'] . '/' . basename($upload_path),
            'post_mime_type' => $file_type['type'],
            'post_title' => preg_replace('/\.[^.]+$/', '', $file_name),
            'post_content' => '',
            'post_status' => 'inherit',
        );
        
        // Insert attachment
        $attachment_id = wp_insert_attachment($attachment, $upload_path);
        
        if (is_wp_error($attachment_id)) {
            @unlink($upload_path);
            return $attachment_id;
        }
        
        // Include image.php for media handling functions
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Generate attachment metadata
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_path);
        
        // Update attachment metadata
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        return $attachment_id;
    }

    /**
     * Check if file is a valid ZIP archive
     *
     * @param string $file_path Path to ZIP file.
     * @return bool True if valid, false otherwise.
     */
    private function is_valid_zip($file_path) {
        if (!file_exists($file_path)) {
            return false;
        }
        
        if (!class_exists('ZipArchive')) {
            // If ZipArchive is not available, use basic check
            $file_info = pathinfo($file_path);
            return strtolower($file_info['extension']) === 'zip';
        }
        
        $zip = new ZipArchive();
        $result = $zip->open($file_path);
        
        if ($result === true) {
            $zip->close();
            return true;
        }
        
        return false;
    }

    /**
     * Get upload error message
     *
     * @param int $error_code Error code.
     * @return string Error message.
     */
    private function get_upload_error_message($error_code) {
        switch ($error_code) {
            case UPLOAD_ERR_INI_SIZE:
                return __('The uploaded file exceeds the upload_max_filesize directive in php.ini.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_FORM_SIZE:
                return __('The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_PARTIAL:
                return __('The uploaded file was only partially uploaded.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_NO_FILE:
                return __('No file was uploaded.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_NO_TMP_DIR:
                return __('Missing a temporary folder.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_CANT_WRITE:
                return __('Failed to write file to disk.', 'nifa-bulk-media-uploader');
            case UPLOAD_ERR_EXTENSION:
                return __('A PHP extension stopped the file upload.', 'nifa-bulk-media-uploader');
            default:
                return __('Unknown upload error.', 'nifa-bulk-media-uploader');
        }
    }

    /**
     * Clean up temporary files
     */
    public function cleanup() {
        // Remove all files in temp directory except index.php and .htaccess
        if (file_exists($this->temp_dir) && is_dir($this->temp_dir)) {
            $files = glob($this->temp_dir . '/*');
            
            foreach ($files as $file) {
                if (is_file($file) && basename($file) !== 'index.php' && basename($file) !== '.htaccess') {
                    @unlink($file);
                }
            }
        }
    }
}
