<?php
/**
 * Integration test file for Nifa Bulk Media Uploader
 * 
 * This file tests the functionality of the plugin
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Test class for Nifa Bulk Media Uploader
 */
class Nifa_Bulk_Media_Uploader_Test {
    /**
     * Run tests
     */
    public static function run_tests() {
        self::test_zip_handler();
        self::test_media_processor();
        self::test_settings();
    }

    /**
     * Test ZIP handler functionality
     */
    private static function test_zip_handler() {
        global $nifa_bulk_media_uploader;
        
        // Create test ZIP file
        $test_dir = WP_CONTENT_DIR . '/uploads/nifa-bmu-test';
        if (!file_exists($test_dir)) {
            wp_mkdir_p($test_dir);
        }
        
        $test_zip = $test_dir . '/test.zip';
        
        // Create a ZIP file with test images
        $zip = new ZipArchive();
        if ($zip->open($test_zip, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            // Add test files
            $test_files = array(
                'test1.jpg' => 'Test JPEG file',
                'test2.png' => 'Test PNG file',
                'test3.gif' => 'Test GIF file',
                'test4.mp4' => 'Test MP4 file',
                'test5.txt' => 'Test TXT file', // Should be skipped
            );
            
            foreach ($test_files as $filename => $content) {
                $zip->addFromString($filename, $content);
            }
            
            $zip->close();
            
            // Test ZIP validation
            $zip_handler = new Nifa_Bulk_Media_Uploader_ZIP_Handler($nifa_bulk_media_uploader);
            $is_valid = $zip_handler->is_valid_zip($test_zip);
            
            if ($is_valid) {
                error_log('ZIP validation test passed');
            } else {
                error_log('ZIP validation test failed');
            }
            
            // Clean up
            @unlink($test_zip);
        } else {
            error_log('Failed to create test ZIP file');
        }
        
        // Clean up test directory
        @rmdir($test_dir);
    }

    /**
     * Test media processor functionality
     */
    private static function test_media_processor() {
        global $nifa_bulk_media_uploader;
        
        // Create test media file
        $test_dir = WP_CONTENT_DIR . '/uploads/nifa-bmu-test';
        if (!file_exists($test_dir)) {
            wp_mkdir_p($test_dir);
        }
        
        $test_image = $test_dir . '/test.jpg';
        file_put_contents($test_image, 'Test JPEG file');
        
        // Test media processor
        $media_processor = new Nifa_Bulk_Media_Uploader_Media_Processor($nifa_bulk_media_uploader);
        $result = $media_processor->process_media_file($test_image, 'test.jpg');
        
        if (is_wp_error($result)) {
            error_log('Media processor test failed: ' . $result->get_error_message());
        } else {
            error_log('Media processor test passed');
            
            // Clean up attachment
            wp_delete_attachment($result, true);
        }
        
        // Clean up
        @unlink($test_image);
        @rmdir($test_dir);
    }

    /**
     * Test settings functionality
     */
    private static function test_settings() {
        global $nifa_bulk_media_uploader;
        
        // Get current settings
        $current_settings = $nifa_bulk_media_uploader->get_settings();
        
        // Test settings update
        $test_settings = array(
            'max_file_size' => 100,
            'allowed_file_types' => array('jpg', 'png', 'gif'),
            'auto_organize' => false,
            'process_limit' => 30,
        );
        
        $result = $nifa_bulk_media_uploader->update_settings($test_settings);
        
        if ($result) {
            error_log('Settings update test passed');
            
            // Restore original settings
            $nifa_bulk_media_uploader->update_settings($current_settings);
        } else {
            error_log('Settings update test failed');
        }
    }
}

// Run tests if in test mode
if (defined('NIFA_BMU_TEST_MODE') && NIFA_BMU_TEST_MODE) {
    add_action('plugins_loaded', array('Nifa_Bulk_Media_Uploader_Test', 'run_tests'), 20);
}
